import java.util.ArrayList;

// needs comments by Aaron3


public interface INode {

    
   public ArrayList<IEdge> edges = null;
   
   public void setName(String value);
   
   public String getName();
   
   public void setId(int value);
   
   public int getId();
  
   
   }
