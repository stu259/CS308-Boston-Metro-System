
public class MetroSystem {
Graph BostonMS = new Graph(0);
}
